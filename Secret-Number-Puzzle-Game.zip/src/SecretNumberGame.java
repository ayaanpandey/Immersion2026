import java.util.Scanner;

class Game {
    private final int[][] cards = {
            {1, 3, 5, 7, 9, 11, 13, 15, 17, 19},
            {2, 3, 6, 7, 10, 11, 14, 15, 18, 19},
            {4, 5, 6, 7, 12, 13, 14, 15, 20},
            {8, 9, 10, 11, 12, 13, 14, 15},
            {16, 17, 18, 19, 20}
    };

    private final int[] cardValues = {1, 2, 4, 8, 16};
    private final Scanner scanner;

    public Game(Scanner scanner) {
        this.scanner = scanner;
    }

    public void showMenu() {
        System.out.println("\\n========== SECRET NUMBER PUZZLE GAME ==========");
        System.out.println("1. View Game Rules");
        System.out.println("2. Display Secret Number Cards");
        System.out.println("3. Play Game");
        System.out.println("4. Play Again");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }

    public void displayRules() {
        System.out.println("\\n========== GAME RULES ==========");
        System.out.println("Think of a number between 1 and 20 and answer Y/N.");
    }

    public void displayCards() {
        for (int i = 0; i < cards.length; i++) {
            System.out.println("\\nCard " + (i + 1) + ":");
            for (int num : cards[i]) System.out.printf("%3d", num);
            System.out.println();
        }
    }

    public void playGame() {
        int result = 0;
        System.out.println("Think of a number between 1 and 20.");
        for (int i = 0; i < cards.length; i++) {
            System.out.println("\\nCard " + (i + 1) + ":");
            for (int num : cards[i]) System.out.printf("%3d", num);
            System.out.print("\\nIs your number present? (Y/N): ");
            String s;
            while (true) {
                s = scanner.nextLine().trim().toUpperCase();
                if (s.equals("Y") || s.equals("YES") || s.equals("N") || s.equals("NO")) break;
                System.out.print("Enter Y/N: ");
            }
            if (s.startsWith("Y")) result += cardValues[i];
        }
        System.out.println("\\nYour Secret Number is: " + result);
    }
}

public class SecretNumberGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Game game = new Game(scanner);
        boolean running = true;

        while (running) {
            game.showMenu();
            try {
                int choice = Integer.parseInt(scanner.nextLine());
                switch (choice) {
                    case 1 -> game.displayRules();
                    case 2 -> game.displayCards();
                    case 3, 4 -> game.playGame();
                    case 5 -> { System.out.println("Goodbye!"); running = false; }
                    default -> System.out.println("Invalid choice!");
                }
            } catch (Exception e) {
                System.out.println("Invalid input!");
            }
        }
        scanner.close();
    }
}