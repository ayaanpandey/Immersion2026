# Online Food Delivery System

Java OOP mini project for food ordering and bill calculation.

## Features
- Customer Management
- Food Item Management
- Bill Calculation
- Order Summary
- OOP Concepts
