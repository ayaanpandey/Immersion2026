class FoodItem {
    private int itemId;
    private String itemName;
    private double price;
    private int quantity;

    public FoodItem(int itemId, String itemName, double price, int quantity) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.price = price;
        this.quantity = quantity;
    }

    public double calculateAmount() {
        return price * quantity;
    }

    public void displayItemDetails() {
        System.out.println("Item ID      : " + itemId);
        System.out.println("Item Name    : " + itemName);
        System.out.println("Price        : ₹" + price);
        System.out.println("Quantity     : " + quantity);
        System.out.println("Amount       : ₹" + calculateAmount());
        System.out.println("--------------------------------");
    }

    public String getItemName() { return itemName; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }
}

class Customer {
    private int customerId;
    private String customerName;
    private String mobileNumber;

    public Customer(int customerId, String customerName, String mobileNumber) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.mobileNumber = mobileNumber;
    }

    public void displayCustomerDetails() {
        System.out.println("Customer ID   : " + customerId);
        System.out.println("Customer Name : " + customerName);
        System.out.println("Mobile Number : " + mobileNumber);
        System.out.println("--------------------------------");
    }

    public String getCustomerName() { return customerName; }
}

public class OnlineFoodDeliverySystem {
    public static void main(String[] args) {
        Customer customer1 = new Customer(101, "Rahul Sharma", "9876543210");
        Customer customer2 = new Customer(102, "Priya Verma", "9876501234");

        FoodItem item1 = new FoodItem(1, "Burger", 120, 2);
        FoodItem item2 = new FoodItem(2, "Pizza", 300, 1);
        FoodItem item3 = new FoodItem(3, "Pasta", 180, 2);
        FoodItem item4 = new FoodItem(4, "Cold Drink", 60, 3);

        FoodItem[] orderItems = {item1, item2, item3, item4};

        System.out.println("===== CUSTOMER DETAILS =====");
        customer1.displayCustomerDetails();

        double totalBill = 0;
        for (FoodItem item : orderItems) {
            item.displayItemDetails();
            totalBill += item.calculateAmount();
        }

        System.out.println("Total Bill : ₹" + totalBill);

        System.out.println("\n===== SECOND CUSTOMER =====");
        customer2.displayCustomerDetails();
    }
}
