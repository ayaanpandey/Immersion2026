# Spring Boot Bank
Starter structure.